PROF. SUJIT MANNA RESEARCH GROUP WEBSITE STARTER

Files:
- index.html          Home page
- team.html           Team page
- research.html       Research page
- publications.html   Publications page
- teaching.html       Teaching page
- vacancies.html      Vacancies page
- contact.html        Contact page
- style.css           Shared design for all pages

HOW TO USE:
1. Upload all eight .html/.css files to the ROOT of your GitHub Pages repository.
2. Keep the filenames exactly as written.
3. Keep style.css in the same root folder as the HTML files.
4. GitHub Pages should be configured to deploy from branch main, folder /(root).
5. Open https://surfacephysics.github.io/surface-physics-repository/ (or your current Pages URL).

IMPORTANT:
The content includes placeholders. Replace sample descriptions, team entries,
publication citations, contact details and vacancy information with verified,
approved information before public use.
